package com.tight.coupling;

public class UserDatabase {
    public String getUserDetails(){
            //Directly acces database here
        return "User details from database";
    }
}
